/**
 * &lt;p&gt;Title: &lt;/p&gt;
 * &lt;p&gt;Description: &lt;/p&gt;
 * &lt;p&gt;Copyright: Copyright (c) 2004&lt;/p&gt;
 * &lt;p&gt;Company: &lt;/p&gt;
 * @author not attributable
 * @version 1.0
 */

public class Room {
  Vector attributes;

  public Room() {
    attributes = new Vector();
  }
}

//Wumpus.java
import java.util.Vector;
import java.io.*;
import java.util.*;

/**
 * &lt;p&gt;Title: &lt;/p&gt;
 * &lt;p&gt;Description: &lt;/p&gt;
 * &lt;p&gt;Copyright: Copyright (c) 2004&lt;/p&gt;
 * &lt;p&gt;Company: &lt;/p&gt;
 * @author not attributable
 * @version 1.0
 */

public class Wumpus {
  //array for the world
  Room[][] world;
  //location of player
  int killed=0;
  int playX;
  int playY;
  int playDir;
  int oldDir;
  int around;
  int ardcnt;
  //location of wumpus
  int wumpusX;
  int wumpusY;
  //location of gold
  int goldX;
  int goldY;
  //for bumps
  String bump=&quot;&quot;;
  String arrow=&quot;&quot;;
  String scream=&quot;&quot;;
  //for making random numbers
  static Random generator;

  public Wumpus() {
    generator = new Random();
  }

  //creates and initializes the Wumpus World
  public void WumpusWorld()
  {
    //places player in room 1,1 facing right
    playX=0;
    playY=0;
    playDir=0;
    //sets initial
    wumpusX=0;
    wumpusY=0;
    goldX=0;
    goldY=0;
    bump=&quot;&quot;;
    arrow=&quot;&quot;;
    around=0;
    ardcnt=0;
    Room current = new Room();
    //creates 4 by 4 array ith each of the rooms
    world = new Room[4][4];
    for (int i = 0; i &lt; 4; i++) {
      for (int j = 0; j &lt; 4; j++) {
        world[i][j] = new Room();
      }
    }
    //randomly select where the wampus is and place it
    while (wumpusX == 0 &amp;&amp; wumpusY == 0) {
      wumpusX = generator.nextInt(4);
      wumpusY = generator.nextInt(4);
    }
    //System.out.println(wumpusX);
    //System.out.println(wumpusY);
    current = world[wumpusX][wumpusY];
    current.attributes.add(&quot;Wumpus&quot;);
    //add the stenches around
    addAround(&quot;Stench&quot;,wumpusX,wumpusY);
    //set the gold
    //randomly select but cant be in 1,1 or with wumpus
    while ( (goldX == 0 &amp;&amp; goldY == 0) || (goldX == wumpusX &amp;&amp; goldY == wumpusY)) {
      goldX = generator.nextInt(4);
      goldY = generator.nextInt(4);
    }
    //System.out.println(goldX);
    //System.out.println(goldY);
    current = world[goldX][goldY];
    current.attributes.add(&quot;glitter&quot;);
    //randomly add pits but not with the gold or in 1,1
    for (int i = 0; i &lt; 4; i++) {
      for (int j = 0; j &lt; 4; j++) {
        //not in the first square
        if (i != 0 &amp;&amp; j != 0) {
          //randly choose should there be a pit
          int rand = generator.nextInt(10);
          //.2 percent make the pit
          if (rand &lt;= 1) {
            //make the pit
            current = world[i][j];
            current.attributes.add(&quot;pit&quot;);
            addAround(&quot;Breeze&quot;,i,j);
          }
        }
      }
    }
    //the world is done and has been successfully been created
  }

//adds the attribute around a point
   public void addAround(String attr, int x, int y)
   {
     Room current=new Room();
     //add the attribute around given point
    x--;
    if(x&gt;=0)
    {
      current = world[x][y];
      current.attributes.add(attr);
    }
    x=x+2;
    if(x&lt;=3)
    {
      current = world[x][y];
      current.attributes.add(attr);
    }
    x--;
    y--;
    if(y&gt;=0)
   {
     current = world[x][y];
     current.attributes.add(attr);
   }
   y=y+2;
    if(y&lt;=3)
    {
      current = world[x][y];
      current.attributes.add(attr);
    }
  }

  //removes attribute from given point
   public void removeAround(String attr, int x, int y)
   {
     //System.out.println(&quot;remove around x: &quot;+x+&quot;  y: &quot;+y);
     Room current=new Room();
     //add the attribute around given point
    x--;
    //System.out.println(&quot;remove around x: &quot;+x+&quot;  y: &quot;+y);
    if(x&gt;=0)
    {
      current = world[x][y];
      current.attributes.remove(attr);
    }
    x=x+2;
    //System.out.println(&quot;remove around x: &quot;+x+&quot;  y: &quot;+y);
    if(x&lt;=3)
    {
      current = world[x][y];
      current.attributes.remove(attr);
    }
    x--;
    y--;
    //System.out.println(&quot;remove around x: &quot;+x+&quot;  y: &quot;+y);
    if(y&gt;=0)
   {
     current = world[x][y];
     current.attributes.remove(attr);
   }
   y=y+2;
   //System.out.println(&quot;remove around x: &quot;+x+&quot;  y: &quot;+y);
    if(y&lt;=3)
    {
      current = world[x][y];
      current.attributes.remove(attr);
    }
  }


//takes the current world state and the agents next action
  //returns the new world state and the cost of the action
  public int result(String action)
  {
    scream=&quot;&quot;;
    String bumps=&quot;&quot;;
    Room current=new Room();
    int retval=-99;
    //take care of left turns
    if(action.equalsIgnoreCase(&quot;turnLeft&quot;))
    {
      turn(-1);
      retval=-1;
    }
    //take care of right turns
    if(action.equalsIgnoreCase(&quot;turnRight&quot;))
    {
      turn(1);
      retval=-1;
    }
    //take care of move forward
    if(action.equalsIgnoreCase(&quot;forward&quot;))
    {
      bumps=move(playDir);
      retval=-1;
      //check for pits and wumpus after moving
      current=world[playX][playY];
      for(int i=0;i&lt;current.attributes.size();i++){
        if( ((String)current.attributes.get(i)).equalsIgnoreCase(&quot;pit&quot;))
        {
          retval = -1000;
          //System.out.println(&quot;Fell in pit result fucntion&quot;);
          killed++;
        }
      }
      if(playX==wumpusX &amp;&amp; playY==wumpusY){
        retval = -1000;
        //System.out.println(&quot;wumpus got me result fucntion&quot;);
        killed++;
      }
    }
    //get the gold
    if(action.equalsIgnoreCase(&quot;grab&quot;))
    {
      current=world[playX][playY];
      for(int i=0;i&lt;current.attributes.size();i++){
        if( ((String)current.attributes.get(i)).equalsIgnoreCase(&quot;glitter&quot;)){
          retval = 1000;
          current.attributes.remove(&quot;glitter&quot;);
          //System.out.println(current.attributes);
        }
      }
      if(retval!=1000){
        retval=-1;
      }
    }
    //checks the fire arrow and sees if it hits wumpus
    if(action.equalsIgnoreCase(&quot;fire&quot;)&amp;&amp;retval!=-1000)
    {
      retval = fire();
    }
    bump=bumps;
    return retval;
  }

  //does the arrow thing and returns 1000 for hit and -10 for miss
  public int fire()
  {
    int retval=-10;
    int x;
    int y;
    Room current=new Room();
    //0 is right
    if(playDir==0){
      x=playX+1;
      while(x&lt;=3){
        current = world[x][playY];
        for(int i=0;i&lt;current.attributes.size();i++){
          if( ((String)current.attributes.get(i)).equalsIgnoreCase(&quot;wumpus&quot;))
            retval=-10;
            current.attributes.remove(&quot;wumpus&quot;);
            removeAround(&quot;stench&quot;,x,playY);
            scream=&quot;yes&quot;;
        }
        x++;
      }
    }
    //1 is up
    if(playDir==1){
      y=playY+1;
      while(y&lt;=3){
        current = world[playX][y];
        for(int i=0;i&lt;current.attributes.size();i++){
          if( ((String)current.attributes.get(i)).equalsIgnoreCase(&quot;wumpus&quot;))
            retval=-10;
            current.attributes.remove(&quot;wumpus&quot;);
            removeAround(&quot;stench&quot;,playX,y);
            scream=&quot;yes&quot;;
        }
        y++;
      }
    }
    //2 is left
    if(playDir==2){
      x=playX-1;
      while(x&gt;=0){
        current = world[x][playY];
        for(int i=0;i&lt;current.attributes.size();i++){
          if( ((String)current.attributes.get(i)).equalsIgnoreCase(&quot;wumpus&quot;))
            retval=-10;
            current.attributes.remove(&quot;wumpus&quot;);
            removeAround(&quot;stench&quot;,x,playY);
            scream=&quot;yes&quot;;
        }
         x--;
      }
    }
    //3 is down
    if(playDir==3){
      y=playY-1;
     while(y&gt;=0){
       current = world[playX][y];
       for(int i=0;i&lt;current.attributes.size();i++){
         if( ((String)current.attributes.get(i)).equalsIgnoreCase(&quot;wumpus&quot;))
           retval=-10;
           current.attributes.remove(&quot;wumpus&quot;);
           removeAround(&quot;stench&quot;,playX,y);
           scream=&quot;yes&quot;;
       }
       y--;
     }
    }
    return retval;
  }

  //turns the person either right or left
  public void turn(int r)
  {
    //0 is right
    //1 is up
    //2 is left
    //3 is down
    oldDir=playDir;
    //turn right
    if(r==1){
      playDir--;
    }else{
      //turn left
      playDir++;
    }
    if(playDir==4)
      playDir=0;
    if(playDir==-1)
      playDir=3;
  }

  //moves the person forward
  //hears a bump if they hit a wall
  //if hits a wall dont move
  public String move(int d)
  {
    String retval=&quot;&quot;;
    //0 is right
    if(d==0){
      playX++;
    }
    //1 is up
    if(d==1){
      playY++;
    }
    //2 is left
    if(d==2){
      playX--;
    }
    //3 is down
    if(d==3){
      playY--;
    }
    if(playX&gt;3){
      playX=3;
      retval=&quot;bump&quot;;
    }
    if(playY&gt;3){
      playY=3;
      retval=&quot;bump&quot;;
    }
    if(playX&lt;0){
      playX=0;
      retval=&quot;bump&quot;;
    }
    if(playY&lt;0){
      playY=0;
      retval=&quot;bump&quot;;
    }
    return retval;
  }

  //does the dump agent stuff
  //looks at the world returns its action
  public String dumbAgent()
  {
    String retval=&quot;&quot;;
    boolean stenchy=false;
    boolean breeze=false;
    //get current senses
    Room current=world[playX][playY];
    for(int i=0;i&lt;current.attributes.size();i++)
    {
      String temp=(String)current.attributes.get(i);
      if(temp.equalsIgnoreCase(&quot;stench&quot;)){
        if(arrow.equalsIgnoreCase(&quot;&quot;)){
          retval=&quot;fire&quot;;
          arrow=&quot;shot&quot;;
        }else{
          arrow=&quot;&quot;;
        }
      }
      if(temp.equalsIgnoreCase(&quot;glitter&quot;))
        retval=&quot;grab&quot;;
    }
    if(retval.equalsIgnoreCase(&quot;&quot;)){
      int pick=generator.nextInt(3);
      //turn left
      if(pick==0){
        retval=&quot;turnLeft&quot;;
      }
      //turn right
      if(pick==1){
        retval=&quot;turnRight&quot;;
     }
     //move forward
     if(pick==2){
       retval=&quot;forward&quot;;
     }
    }
    return retval;
  }

  //does the smart agent stuff
  //when it comes to a stench or breeze it will try to go around it.
  //tries to go around things using the right hand maze rule
//looks at the world returns its action
public String SmartAgent()
{
  String retval=&quot;&quot;;
  boolean stenchy=false;
  boolean breeze=false;
  //get current senses
  Room current=world[playX][playY];
    for(int i=0;i&lt;current.attributes.size();i++)
    {
      String temp=(String)current.attributes.get(i);
      if(temp.equalsIgnoreCase(&quot;stench&quot;)){
        stenchy=true;
      }
      if(temp.equalsIgnoreCase(&quot;glitter&quot;)){
        retval = &quot;grab&quot;;
        //if there is glitter there is nothing else we would want to do
        return retval;
      }
      if(temp.equalsIgnoreCase(&quot;breeze&quot;))
        breeze=true;
    }
    //first if you haven&apos;t moved and it is your first turn
    //just go forward
    if(playX==0 &amp;&amp; playY==0 &amp;&amp; playDir==0)
    {
      retval=&quot;forward&quot;;
    }
    //if you killed the wumpus move forward
    if(!scream.equalsIgnoreCase(&quot;&quot;)&amp;&amp; retval.equalsIgnoreCase(&quot;&quot;))
    {
      if(breeze!=true){
        retval = &quot;forward&quot;;
        return retval;
      }else{//it is dead but there might be a pit
          retval=&quot;turnLeft&quot;;
          around++;
      }
    }
      if(breeze==true){
        //System.out.print(&quot;breeze: &quot;);
        //try to go around pits
        if(around==0 || around==3){
          //System.out.print(&quot;around 1 cnt is: &quot;+ardcnt+&quot;: &quot;);
          around=1;
          ardcnt++;
          if(ardcnt&gt;11){
            around=0;
            retval= &quot;forward&quot;;
          }else{
            //turn left
            retval = &quot;turnLeft&quot;;
          }
        }
      }
      if(stenchy==true){
        //try to go around wumpus
        if (around == 0) {
          //System.out.print(&quot;around 1: &quot;);
          around = 1;
          ardcnt++;
          if (ardcnt &gt; 11) {
            around = 0;
            retval = &quot;forward&quot;;
          }
          else {
            //turn left
            retval = &quot;turnLeft&quot;;
          }
        }
      }
      if(retval.equalsIgnoreCase(&quot;&quot;)){
      //if it started going around something
      //finish going around it
      if(around==1){
          around=2;
          //System.out.print(&quot;around 2: &quot;);
          retval=&quot;turnLeft&quot;;
        }else if(around==2){
          //turn right
          retval=&quot;forward&quot;;
          //System.out.print(&quot;around 3: &quot;);
          around=3;
        }else if(around==3){
          around=0;
          //System.out.print(&quot;around 4: &quot;);
          retval=&quot;turnRight&quot;;
        }
        //havent found something to do yet
        //go do something random and hope for the best hehe
        //but walk forward a little more often
        //if there is nothing sensed walk forward always
      if(retval.equalsIgnoreCase(&quot;&quot;)){
          int pick = generator.nextInt(3);
          //nothing to fear try a new block
        if(breeze==false &amp;&amp; stenchy==false){
          retval = &quot;forward&quot;;
          //System.out.print(&quot;no fear: &quot;);
          pick=-1;
        }
        //System.out.print(&quot;random: &quot;);
        //turn left
        if (pick == 0) {
          retval = &quot;turnRight&quot;;
        }
        //turn right
        if (pick == 1) {
          retval = &quot;turnRight&quot;;
        }
        //move forward
        if (pick &gt;= 2) {
          retval = &quot;forward&quot;;
        }
      }
    }
    //we have a decision but lets make sure  we wont try to walk into a walk
    //0 is right
    //1 is up
    //2 is left
    //3 is down
    //walking left off board
    if(playX==0 &amp;&amp; playDir==2){
      retval = &quot;turnRight&quot;;
      //System.out.print(&quot;wall: &quot;);
    }
    //walking down off board
    if(playY==0 &amp;&amp; playDir==3){
      retval = &quot;turnRight&quot;;
      //System.out.print(&quot;wall: &quot;);
    }
    if(playX==3 &amp;&amp; playDir==0){
      retval = &quot;turnRight&quot;;
      //System.out.print(&quot;wall: &quot;);
    }
    if(playY==3 &amp;&amp; playDir==1){
      retval = &quot;turnRight&quot;;
      //System.out.print(&quot;wall: &quot;);
    }
       //it wont walk into a wall go for it
    return retval;
}


  //this is to test and run the program
  public static void main(String args[]){
    Wumpus test;
    int score;
    int moves;
    int points;
    int avg=0;
    int times=0;
    String doA=&quot;&quot;;
    System.out.println(&quot;Starting Simulation&quot;);
    //System.out.println(&quot;Attributes are&quot;);
    //for (int i = 0; i &lt; 4; i++) {
     //for (int j = 0; j &lt; 4; j++) {
       //System.out.println(i+&quot; , &quot;+j+&quot; : &quot;+test.world[i][j].attributes);
     //}
   //}
   test = new Wumpus();

   while(times&lt;10000){
     times++;
     test.WumpusWorld();
     score=0;
     moves=0;
     points=0;
     test.around=0;
     while ( (points != -1000 &amp;&amp; points != 1000) &amp;&amp; moves &lt; 1000) {
       if (moves &lt; 1000) {
         doA = test.dumbAgent();
         points = test.result(doA);
         //System.out.println(&quot;Action: &quot;+doA+&quot;   points: &quot;+points+&quot;    moves: &quot; + moves);
         score = score + points;
       }
       moves++;
     }
     //System.out.println(&quot;Score: &quot; + score);
     avg=avg+score;
   }
   System.out.println(&quot;Dumb agent average: &quot;+avg/10000);

   //run the same tests with the smart agent yes 10000 more times
  times=0;
  avg=0;
  while(times&lt;10000){
    times++;
    test.WumpusWorld();
    score=0;
    moves=0;
    points=0;
    while ( (points != -1000 &amp;&amp; points != 1000) &amp;&amp; moves &lt; 1000) {
      if (moves &lt; 1000) {
        doA = test.SmartAgent();
        points = test.result(doA);
        score = score + points;
       //System.out.println(&quot;Action: &quot;+doA+&quot;   points: &quot;+points+&quot;    moves: &quot; + moves+&quot;  score: &quot;+score);
       //System.out.println(&quot;state[&quot;+test.playX+&quot;,&quot;+test.playY+&quot;,&quot;+test.playDir+&quot;]: &quot;+(test.world[test.playX][test.playY]).attributes);
      }
      moves++;
    }
    //System.out.println(&quot;Score: &quot; + score);
    avg=avg+score;
  }
  System.out.println(&quot;Smart agent average: &quot;+avg/10000);

  System.out.println(&quot;How many times were you killed out of 20000: &quot;+test.killed);


}
}